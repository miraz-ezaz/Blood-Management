package com.cbtest.findadonortest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SendRequestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_request);
    }
}